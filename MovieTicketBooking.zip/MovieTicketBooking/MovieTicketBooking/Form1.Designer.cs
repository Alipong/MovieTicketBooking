﻿namespace MovieTicketBooking
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOrder = new System.Windows.Forms.Button();
            this.txtName = new System.Windows.Forms.TextBox();
            this.comboBoxFilmType = new System.Windows.Forms.ComboBox();
            this.rbRegular = new System.Windows.Forms.RadioButton();
            this.rbVIP = new System.Windows.Forms.RadioButton();
            this.chkServices = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnOrder
            // 
            this.btnOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnOrder.Location = new System.Drawing.Point(104, 210);
            this.btnOrder.Name = "btnOrder";
            this.btnOrder.Size = new System.Drawing.Size(75, 23);
            this.btnOrder.TabIndex = 0;
            this.btnOrder.Text = "Order";
            this.btnOrder.UseVisualStyleBackColor = true;
            this.btnOrder.Click += new System.EventHandler(this.btnOrder_Click);
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtName.Location = new System.Drawing.Point(105, 57);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 23);
            this.txtName.TabIndex = 1;
            // 
            // comboBoxFilmType
            // 
            this.comboBoxFilmType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxFilmType.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.comboBoxFilmType.FormattingEnabled = true;
            this.comboBoxFilmType.Items.AddRange(new object[] {
            "Action",
            "Komedi",
            "Drama"});
            this.comboBoxFilmType.Location = new System.Drawing.Point(105, 89);
            this.comboBoxFilmType.Name = "comboBoxFilmType";
            this.comboBoxFilmType.Size = new System.Drawing.Size(121, 24);
            this.comboBoxFilmType.TabIndex = 2;
            // 
            // rbRegular
            // 
            this.rbRegular.AutoSize = true;
            this.rbRegular.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbRegular.Location = new System.Drawing.Point(104, 121);
            this.rbRegular.Name = "rbRegular";
            this.rbRegular.Size = new System.Drawing.Size(76, 21);
            this.rbRegular.TabIndex = 3;
            this.rbRegular.TabStop = true;
            this.rbRegular.Text = "Regular";
            this.rbRegular.UseVisualStyleBackColor = true;
            // 
            // rbVIP
            // 
            this.rbVIP.AutoSize = true;
            this.rbVIP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbVIP.Location = new System.Drawing.Point(104, 145);
            this.rbVIP.Name = "rbVIP";
            this.rbVIP.Size = new System.Drawing.Size(47, 21);
            this.rbVIP.TabIndex = 4;
            this.rbVIP.TabStop = true;
            this.rbVIP.Text = "VIP";
            this.rbVIP.UseVisualStyleBackColor = true;
            // 
            // chkServices
            // 
            this.chkServices.AutoSize = true;
            this.chkServices.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.chkServices.Location = new System.Drawing.Point(104, 177);
            this.chkServices.Name = "chkServices";
            this.chkServices.Size = new System.Drawing.Size(176, 21);
            this.chkServices.TabIndex = 5;
            this.chkServices.Text = "Makanan Dan Minuman";
            this.chkServices.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label1.Location = new System.Drawing.Point(41, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "Nama";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.Location = new System.Drawing.Point(41, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 17);
            this.label2.TabIndex = 7;
            this.label2.Text = "Kursi";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.Location = new System.Drawing.Point(41, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "FIlm";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(57, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(223, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "Aplikasi Pemesanan Tiket Film";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(333, 282);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.chkServices);
            this.Controls.Add(this.rbVIP);
            this.Controls.Add(this.rbRegular);
            this.Controls.Add(this.comboBoxFilmType);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.btnOrder);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOrder;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.ComboBox comboBoxFilmType;
        private System.Windows.Forms.RadioButton rbRegular;
        private System.Windows.Forms.RadioButton rbVIP;
        private System.Windows.Forms.CheckBox chkServices;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}

