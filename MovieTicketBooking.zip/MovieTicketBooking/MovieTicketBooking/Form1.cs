﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieTicketBooking
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            // Validasi input
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Nama pembeli tidak boleh kosong!");
                return;
            }

            // Menentukan tipe kursi
            string seatType = rbRegular.Checked ? "Regular" : "VIP";

            // Membuat objek Ticket
            Ticket ticket = new Ticket(txtName.Text, comboBoxFilmType.SelectedItem.ToString(), seatType, chkServices.Checked);

            // Menghitung total harga
            double totalPrice = ticket.CalculateTotalPrice();

            // Menampilkan ringkasan pesanan
            MessageBox.Show($"Nama: {ticket.Name}\nFilm: {ticket.FilmType}\nTipe Kursi: {ticket.SeatType}\nLayanan Tambahan: {(ticket.AdditionalServices ? "Ya" : "Tidak")}\nTotal Harga: {totalPrice:C}");
        }
    }
}
