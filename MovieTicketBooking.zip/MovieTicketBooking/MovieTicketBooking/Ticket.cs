﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieTicketBooking
{
    public class Ticket
    {
        public string Name { get; set; }
        public string FilmType { get; set; }
        public string SeatType { get; set; }
        public bool AdditionalServices { get; set; }

        public Ticket(string name, string filmType, string seatType, bool additionalServices)
        {
            Name = name;
            FilmType = filmType;
            SeatType = seatType;
            AdditionalServices = additionalServices;
        }

        public double CalculateTotalPrice()
        {
            double basePrice = SeatType == "VIP" ? 80000 : 50000; // Harga dasar
            double additionalPrice = AdditionalServices ? 30000 : 0; // Harga tambahan

            return basePrice + additionalPrice;
        }
    }

}
